clear;clc;close all;
 
image = imread('./images/img3.png');

[result] = infer(image);

figure
imshow(image)

figure
imshow(result)
