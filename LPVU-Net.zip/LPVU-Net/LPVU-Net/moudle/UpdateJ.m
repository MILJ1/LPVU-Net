function moudle = UpdateJ(x, var)

moudle = Layer(@updJ, x, var{:});

end

