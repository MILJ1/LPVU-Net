function moudle = UpdateB(x, var)

moudle = Layer(@updB, x, var{:});

end

