function moudle = UpdateY(x, var)

moudle = Layer(@updY, x, var{:});

end

