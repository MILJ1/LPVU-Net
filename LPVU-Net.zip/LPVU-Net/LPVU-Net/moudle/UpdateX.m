function moudle = UpdateX(x, var)

moudle = Layer(@updX, x, var{:});

end

