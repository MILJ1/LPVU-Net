function moudle = Padding(x, var)

moudle = Layer(@padding, x, var{:});

end

