function moudle = Upsample(x, var)

moudle = Layer(@upsampling, x, var{:});

end

